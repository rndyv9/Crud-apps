from fastapi.testclient import TestClient
from app.main import app
import pytest
from app.database import Base, engine

client = TestClient(app)

@pytest.fixture(autouse=True)
def reset_db():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)

def test_insert():
    print("\n[TEST] Adding")

    response = client.post("/contact", params={
        "name": "John",
        "phone": "123"
    })

    assert response.status_code == 200
    assert response.json()["message"] in ["created", "no change"]

    data = client.get("/contacts").json()
    names = [c["name"] for c in data]
    assert "John" in names


def test_update():
    print("\n[TEST] Updating")

    client.post("/contact", params={"name": "John", "phone": "123"})

    response = client.post("/contact", params={
        "name": "John",
        "phone": "222"
    })

    assert response.status_code == 200
    assert response.json()["message"] == "updated"

    data = client.get("/contacts").json()
    phone = [c["phone_number"] for c in data if c["name"] == "John"][0]
    assert phone == "222"


def test_delete():
    print("\n[TEST] Deleting")

    client.post("/contact", params={"name": "John", "phone": "222"})

    response = client.delete("/contact/John")

    assert response.status_code == 200
    assert response.json()["message"] == "deleted"

    data = client.get("/contacts").json()
    names = [c["name"] for c in data]
    assert "John" not in names
